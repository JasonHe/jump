﻿<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1"/>

<script language=JavaScript>
document.oncontextmenu=new Function("event.returnValue=false;");
document.onselectstart=new Function("event.returnValue=false;");
</script>

<SCRIPT LANGUAGE="JavaScript">
function a(){
setTimeout("b()",1);//点击按钮一秒钟后跳转到随机页面
}
function b(){//跳转函数
var url = [ "https://xxx.cn", 
"https://xxxxx.cn", 
"https://域名",
"https://域名",
"https://域名",
"https://域名",
"https://域名",
"https://域名",
"https://域名",
"https://域名",


];                                                         
var r = Math.floor(Math.random() * 10);
window.location.href = url[r];

}
</SCRIPT>




</head>
<body onLoad="javascript:a();">



</body>
</html>